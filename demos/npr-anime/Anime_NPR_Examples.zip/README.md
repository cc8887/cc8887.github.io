# 二次元游戏技术启发对照
这不是任何游戏的精确复刻，也不使用游戏资产。同一个 Blender Suzanne，CPU 三角光栅化。

## 来源与教学简化
- Guilty Gear Xrd GDC 2015 官方资料 p17–23：https://media.gdcvault.com/gdc2015/presentations/Motomura_Junya_GuiltyGearXrd.pdf
  该作品使用可控阈值、编辑顶点法线、每角色光向、暗部色与线宽控制。本示例在片元着色处混合法线来解释控制结果，并非真正修改模型顶点；参数刻意夸张，眼鼻结构变平是风险而非改善保证。
- Unity Toon Shader Angel Ring：https://docs.unity3d.com/Packages/com.unity.toonshader@0.10/manual/AngelRing.html
  官方文档的高光依赖相机与 UV2；这里仅展示艺术化条带高光目的，不实现 Angel Ring 或各向异性头发 BSDF。猴头没有头发，不能据此验证真实发型效果。
- 社区面部光照分析实现：https://github.com/ChiliMilk/URP_Toon 和 https://github.com/GID0317/URPSimpleGenshinShaders
  非游戏官方源码。我们的原始灰度纹理为平面投影阈值图，未计算距离场，不能叫真实 SDF。换光图控制量为简化教学映射，尚未实现头部坐标光向同步、左右翻转及真实角色UV。固定灰度阈值测试与固定黑白阴影遮罩不同。

## Godot 迁移
应在真实模型上保存自定义法线/顶点色阈值，在 shader 中以相同主光数据进行计算；脸部阈值纹理要按角色UV重新绘制，使用头部局部光向控制阈值，并处理左右镜像；不可直接把猴头平面投影当生产脸部 shader。
提供 Python 渲染源与纹理，只验证CPU图。没有Godot/GPU视觉验收、性能测量或真实投影。组合示例只是教学，不是最终美术质量。
