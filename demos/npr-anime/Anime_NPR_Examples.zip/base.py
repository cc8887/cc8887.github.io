import json,numpy as np
from PIL import Image,ImageDraw,ImageFont
from scipy.ndimage import maximum_filter,minimum_filter
from pathlib import Path
D=Path(__file__).parent;O=D/'output';O.mkdir(exist_ok=True)
m=json.load(open(D/'model_uv.json'));P=np.array(m['positions']).reshape(-1,3,3);N=np.array(m['normals']).reshape(-1,3,3)
S=620;a=np.radians(22);M=np.array([[np.cos(a),0,-np.sin(a)],[0,1,0],[np.sin(a),0,np.cos(a)]])
zbuf=np.full((S,S),-1e9);nb=np.zeros((S,S,3));pos=np.zeros_like(nb)
for p,n in zip(P,N):
 pp=p@M.T;q=np.column_stack([S/2+pp[:,0]*S/3.25,S/2-pp[:,1]*S/3.25,pp[:,2]]);a,b,c=q;den=(b[1]-c[1])*(a[0]-c[0])+(c[0]-b[0])*(a[1]-c[1])
 if den>=0:continue
 x0=max(0,int(q[:,0].min()));x1=min(S-1,int(np.ceil(q[:,0].max())));y0=max(0,int(q[:,1].min()));y1=min(S-1,int(np.ceil(q[:,1].max())))
 xx,yy=np.meshgrid(np.arange(x0,x1+1)+.5,np.arange(y0,y1+1)+.5);u=((b[1]-c[1])*(xx-c[0])+(c[0]-b[0])*(yy-c[1]))/den;v=((c[1]-a[1])*(xx-c[0])+(a[0]-c[0])*(yy-c[1]))/den;t=1-u-v;bc=np.stack([u,v,t],-1);sl=np.s_[y0:y1+1,x0:x1+1];z=bc@pp[:,2];ok=(u>=0)&(v>=0)&(t>=0)&(z>zbuf[sl]);zbuf[sl][ok]=z[ok];nb[sl][ok]=(bc@n)[ok];pos[sl][ok]=(bc@pp)[ok]
valid=zbuf>-1e8;nb/=np.maximum(np.linalg.norm(nb,axis=-1)[...,None],1e-9);nv=nb@M.T;L=np.array([.45,.55,.8]);L/=np.linalg.norm(L);dot=nb@L;lit=np.maximum(dot,0);warm=np.array([246,211,144]);cool=np.array([89,91,139]);mid=np.array([189,154,139]);paper=np.array([246,238,216]);ink=np.array([41,46,65]);yy,xx=np.indices((S,S));outer=maximum_filter(valid,size=5)&~valid
mix=lambda a,b,t:a+(b-a)*t[...,None]
base=mix(cool,warm,.15+.85*lit)
cel=np.where((lit>.48)[...,None],warm,cool)
ramp=mix(np.array([51,73,114]),np.array([239,112,108]),np.minimum(lit/.5,1));ramp=np.where((lit>.5)[...,None],mix(np.array([239,112,108]),np.array([255,229,166]),np.maximum((lit-.5)*2,0)),ramp)
gooch=mix(np.array([69,102,170]),np.array([233,193,73]),(dot+1)/2)
# Approximate display-linear examples, no cast shadows/PBR.
spacing=14;rx=(xx%spacing-spacing/2)/spacing;ry=(yy%spacing-spacing/2)/spacing;rad=.47*np.sqrt(1-lit);dots=rx*rx+ry*ry<rad*rad;half=np.where(dots[...,None],ink,paper)
line1=((xx+yy)%12)<2;line2=((xx-yy)%13)<2;line3=(xx%10)<2;hatch=(line1&(lit<.8))|(line2&(lit<.5))|(line3&(lit<.2));hat=np.where(hatch[...,None],ink,paper)
edge=outer.copy();edgeinside=np.zeros((S,S),bool)
for ax in (0,1):
 nn=np.roll(nv,1,axis=ax);vv=np.roll(valid,1,axis=ax);zz=np.roll(zbuf,1,axis=ax);edgeinside|=valid&vv&((np.linalg.norm(nv-nn,axis=-1)>.24)|(abs(zbuf-zz)>.12))
edgem=np.zeros_like(base)+paper;edgem[edgeinside]=ink
rim=np.maximum(1-np.maximum(nv[:,:,2],0),0)**3;rim= np.clip((rim-.07)/.45,0,1);rimcol=mix(cel,np.array([112,231,236]),rim*.9)
# MatCap texture synthesized from view-space normal disk, sampled through indexed image lookup.
T=512;ty,tx=np.indices((T,T));u=tx/(T-1)*2-1;v=1-ty/(T-1)*2;nz=np.sqrt(np.maximum(0,1-u*u-v*v));mcap=mix(np.array([62,55,109]),np.array([221,136,156]),np.clip(.5+.35*u+.35*v,0,1));shine=np.exp(-((u+.32)**2+(v-.4)**2)/.026);mcap=mix(mcap,np.array([255,241,206]),shine*.95);mcap[(u*u+v*v)>1]=[240,240,240];Image.fromarray(np.uint8(np.clip(mcap,0,255))).save(O/'MatCap_texture.png');mx=np.clip(((nv[:,:,0]*.5+.5)*(T-1)).astype(int),0,T-1);my=np.clip(((.5-nv[:,:,1]*.5)*(T-1)).astype(int),0,T-1);mat=mcap[my,mx]
items=[('00_lambert','平滑明暗 · 基准',base,'连续 N·L；不属于本次 NPR 重点'),('01_cel','Cel · 硬边色块',cel,'光照阈值切成两段'),('02_ramp','Ramp · 艺术色带',ramp,'用光照强度查自定义颜色'),('03_gooch','Gooch · 冷暖着色',gooch,'背光冷、迎光暖，保留中间调'),('04_halftone','Halftone · 漫画网点',half,'暗处点更大；屏幕空间图案'),('05_hatching','Hatching · 交叉排线',hat,'暗部叠更多方向；屏幕空间简化'),('06_edges','轮廓 · 深度与法线边缘',edgem,'外轮廓 + 内部深度/法线变化'),('07_rim','Rim · 轮廓光叠加',rimcol,'Cel 基础 + 视角相关边缘光'),('08_matcap','MatCap · 材质球映射',mat,'视空间法线查图；不响应场景灯')]
font='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc';f=lambda s:ImageFont.truetype(font,s)
sheet=Image.new('RGB',(1860,2310),'#f1f4f5');d=ImageDraw.Draw(sheet);d.text((40,25),'同一个猴头，九种着色对照',font=f(44),fill='#253744');d.text((40,90),'固定模型、视角和主光 · 不同方法并非互斥，可以组合使用',font=f(25),fill='#586b79')
meta=[]
for i,(id,title,col,desc) in enumerate(items):
 im=np.zeros((S,S,3))+[227,234,239];im[valid]=col[valid];
 if id=='06_edges':im[outer]=ink
 im=Image.fromarray(np.uint8(np.clip(im,0,255)));im.save(O/(id+'.png'));x=i%3*620;y=150+i//3*710;sheet.paste(im,(x,y));d.text((x+25,y+620),title,font=f(28),fill='#253744');d.text((x+25,y+663),desc,font=f(20),fill='#586b79');meta.append({'id':id,'title':title,'desc':desc})
d.text((40,2290),'CPU 三角形光栅化示例；无真实投影；非 GPU/Godot 性能或画面验收',font=f(17),fill='#586b79');sheet.save(O/'NPR_Algorithm_Comparison.png');json.dump(meta,open(O/'examples.json','w'),ensure_ascii=False,indent=2)
print('Rendered',len(items))
