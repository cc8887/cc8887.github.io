import base as b
from PIL import Image,ImageDraw,ImageFont
import numpy as np,json
from pathlib import Path
O=Path(__file__).parent/'output';S=b.S;V=b.valid;P=b.pos@b.M;N=b.nb;L=b.L
norm=lambda x:x/np.maximum(np.linalg.norm(x,axis=-1,keepdims=True),1e-8)
w=np.array([246,211,144]);c=np.array([104,99,149]);mid=np.array([193,153,150]);ink=np.array([48,44,65]);mix=b.mix
# Analytical edited vertex normal analogue: blend head-facing normals in facial region.
face=np.clip((.95-abs(P[:,:,0]))/.25,0,1)*np.clip((P[:,:,2]-.05)/.5,0,1)
E=norm(N*(1-face[...,None]*.72)+np.array([0,.1,1])*face[...,None]*.72)
cel=lambda d,t:np.where((d>t)[...,None],w,c)
base=cel(N@L,.48);edited=cel(E@L,.48)
# Per-point threshold modulation demonstrates vertex-color threshold art direction.
th=.48+.32*np.exp(-((P[:,:,1]+.28)/.34)**2)-.25*np.exp(-((P[:,:,1]-.45)/.25)**2)
local=cel(N@L,th)
# Original planar face-control texture, not a signed distance field and not a game asset.
T=512;y,x=np.indices((T,T));u=x/(T-1);v=y/(T-1);maptex=np.clip(.12+.78*u+.16*np.sin(v*5.8)+.10*np.exp(-((v-.55)/.13)**2),0,1)
Image.fromarray(np.uint8(maptex*255)).save(O/'FaceThresholdMap.png')
u=np.clip(P[:,:,0]/2+.5,0,1);v=np.clip(.5-P[:,:,1]/2,0,1);tx=np.clip((u*511).astype(int),0,511);ty=np.clip((v*511).astype(int),0,511);sample=maptex[ty,tx];facecol=cel(sample,.48);facectrl=mix(base,facecol,face)
# Artist-defined band highlight driven by model coordinates, not hair anisotropic BSDF.
band=(abs(P[:,:,1]-(.48+.10*np.sin(P[:,:,0]*4)))<.055)&(P[:,:,1]>.1)&(P[:,:,2]>.05)
high=base.copy();high[band]=[255,247,207]
combined=cel(E@L,th);combined=mix(combined,facecol,face*.7);combined[band]=[255,247,207]
items=[('baseline','基准 · 普通二分',base,'统一阈值 + 原始法线'),('normals','形体控制 · 编辑法线',edited,'面部光照更整体；几何轮廓不变'),('threshold','局部阈值 · 阴影设计',local,'不同区域更容易变亮或变暗'),('face','面部阈值图 · 教学简化',facectrl,'采样预绘灰度图；不是固定黑白遮罩'),('highlight','艺术化条带高光',high,'专门设计高光形状；非物理头发'),('combined','组合示例',combined,'法线 + 局部阈值 + 面部控制 + 高光')]
font=lambda s:ImageFont.truetype('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc',s)
sheet=Image.new('RGB',(1860,1640),'#f0f3f6');d=ImageDraw.Draw(sheet);d.text((35,20),'二次元渲染：从“算法”到“美术控制”',font=font(43),fill='#263746');d.text((35,85),'同一猴头、相同光向与相机 · 游戏技术启发的教学例子，不是游戏画面复刻',font=font(24),fill='#637583')
meta=[]
for i,(id,title,col,desc) in enumerate(items):
 im=np.zeros((S,S,3))+[227,234,239];im[V]=col[V];im[b.outer]=ink
 im=Image.fromarray(np.uint8(np.clip(im,0,255)));im.save(O/(id+'.png'));xx=i%3*S;yy=140+i//3*720;sheet.paste(im,(xx,yy));d.text((xx+20,yy+620),title,font=font(28),fill='#263746');d.text((xx+20,yy+663),desc,font=font(20),fill='#637583');meta.append({'id':id,'title':title,'desc':desc})
d.text((35,1600),'CPU 渲染；法线控制为着色阶段模拟；面部图为平面投影阈值纹理，非真实 SDF；Godot 尚未移植验收。',font=font(19),fill='#637583');sheet.save(O/'Anime_NPR_Comparison.png');json.dump(meta,open(O/'examples.json','w'),ensure_ascii=False,indent=2)
# Show texture and directional transition, without pretending this is full face SDF.
canvas=Image.new('RGB',(1860,760),'#f0f3f6');dd=ImageDraw.Draw(canvas);dd.text((30,15),'面部控制图：灰度不是阴影，而是“何时进入阴影”的阈值',font=font(33),fill='#263746')
for i,q in enumerate((.25,.5,.75)):
 co=mix(base,cel(sample,q),face);im=np.zeros((S,S,3))+[227,234,239];im[V]=co[V];canvas.paste(Image.fromarray(np.uint8(im)),(i*S,65));dd.text((i*S+25,690),f'面部光向控制量 = {q}（教学映射）',font=font(24),fill='#263746')
canvas.save(O/'Face_Control_Comparison.png')
